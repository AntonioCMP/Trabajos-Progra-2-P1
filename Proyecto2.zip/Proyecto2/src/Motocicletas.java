public class Motocicletas {
        String marca="N/A";  //Propiedad de tipo OBJETO string
        String modelo;
        String color;
        double cilindraje; //Tipo de dato NATIVO, el mismo que en c
        int numAsientos;

        public Motocicletas() {
        }

        public Motocicletas(String marca) {
                this.marca = marca;
        }

        public void detalle(){
                System.out.println("Datos del objeto moto - Clase Motocicletas");
                System.out.println("Marca: "+ this.marca);
                System.out.println("Modelo: "+ this.modelo);
                System.out.println("Color: "+ this.color);
                System.out.println("Cilindraje: "+ this.cilindraje);
                System.out.println();
        }

}
