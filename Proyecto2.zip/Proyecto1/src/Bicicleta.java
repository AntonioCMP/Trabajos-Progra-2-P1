public class Bicicleta{
    String marca;  //Propiedad de tipo OBJETO string
    String modelo;
    String color;
    String marcaSuspension; //Tipo de dato NATIVO, el mismo que en c
    int numSuspenciones;
    //TODO NUMERICO USAR NATIVO


}
